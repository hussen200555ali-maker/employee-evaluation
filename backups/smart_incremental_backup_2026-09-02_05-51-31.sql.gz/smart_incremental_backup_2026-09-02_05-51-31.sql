-- MySQL Backup - Professional System
-- Generated: 2026-09-02 05:51:31
-- Database: employee_evaluation_mvc
-- PHP Version: 8.2.12
-- Backup Type: Professional
SET FOREIGN_KEY_CHECKS=0;
SET NAMES utf8mb4;

-- Backup Type: SMART INCREMENTAL
-- Generated: 2026-09-02 05:51:31


-- --------------------------------------------------------
-- Table structure for table `audit_logs`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT 'معرف المستخدم الذي قام بالإجراء (NULL إذا كان الإجراء من النظام)',
  `action` varchar(100) NOT NULL COMMENT 'وصف الإجراء (مثل: USER_LOGIN)',
  `entity_type` varchar(50) DEFAULT NULL COMMENT 'اسم الجدول الذي تأثر بالإجراء',
  `entity_id` int(11) DEFAULT NULL COMMENT 'معرف السجل الذي تأثر',
  `details` text DEFAULT NULL COMMENT 'تفاصيل إضافية عن الإجراء (مثل القيم القديمة والجديدة)',
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='سجل تدقيق لجميع العمليات المهمة في النظام.';

--
-- Data for table `audit_logs`
--

INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('275', NULL, 'USER_LOGIN_FAILED', 'users', NULL, '{\"username_attempt\":\"admin\"}', '::1', '2026-08-24 03:09:51');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('276', NULL, 'USER_LOGIN_FAILED', 'users', NULL, '{\"username_attempt\":\"admin\"}', '::1', '2026-08-24 03:09:58');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('277', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-24 03:12:04');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('278', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-24 03:23:43');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('279', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-24 03:23:57');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('280', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-24 03:30:05');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('281', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-24 03:32:45');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('282', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-24 03:41:40');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('283', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-24 03:43:17');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('284', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-24 03:47:10');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('285', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-24 03:47:31');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('286', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-24 03:48:56');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('287', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-24 03:55:32');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('288', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-24 03:56:31');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('289', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-24 03:56:47');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('290', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-24 04:15:25');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('291', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-24 05:03:54');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('292', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-31 03:03:54');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('293', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-31 03:04:30');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('294', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-31 03:06:59');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('295', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-31 03:39:08');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('296', '1', 'EVALUATION_STARTED', 'evaluations', '17', '{\"evaluated\":\"بدر علي الخالدي\",\"template_id\":1}', '::1', '2026-08-31 03:45:47');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('297', '1', 'EVALUATION_STARTED', 'evaluations', '18', '{\"evaluated\":\"سلطان ناصر القرني\",\"template_id\":1}', '::1', '2026-08-31 03:49:13');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('298', '1', 'EVALUATION_SUBMITTED', 'evaluations', '18', NULL, '::1', '2026-08-31 03:50:00');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('299', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-31 03:52:35');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('300', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '19', '{\"batch_id\":1,\"emp_code\":\"EMP-002\",\"evaluation_date\":\"2026-08-29\"}', NULL, '2026-08-31 03:53:05');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('301', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '20', '{\"batch_id\":1,\"emp_code\":\"EMP-999\",\"evaluation_date\":\"2026-08-29\"}', NULL, '2026-08-31 03:53:05');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('302', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-31 03:53:31');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('303', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-31 03:53:41');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('304', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-31 03:57:14');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('305', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-31 04:03:33');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('306', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '21', '{\"batch_id\":15,\"emp_code\":\"15555\",\"evaluation_date\":\"2026-05-20\"}', '::1', '2026-08-31 04:13:58');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('307', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '22', '{\"batch_id\":15,\"emp_code\":\"256464\",\"evaluation_date\":\"2026-05-20\"}', '::1', '2026-08-31 04:13:58');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('308', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-31 04:26:38');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('309', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '23', '{\"batch_id\":17,\"emp_code\":\"EMP-002\",\"evaluation_date\":\"2026-08-30\"}', NULL, '2026-08-31 04:28:31');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('310', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '24', '{\"batch_id\":17,\"emp_code\":\"EMP-9999\",\"evaluation_date\":\"2026-08-30\"}', NULL, '2026-08-31 04:28:31');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('311', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '25', '{\"batch_id\":19,\"emp_code\":\"242452\",\"evaluation_date\":\"2025-05-05\"}', '::1', '2026-08-31 04:33:51');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('312', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-08-31 19:15:20');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('313', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '26', '{\"batch_id\":20,\"emp_code\":\"124004\",\"evaluation_date\":\"2026-05-02\"}', '::1', '2026-08-31 19:17:23');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('314', '1', 'EVALUATION_SUBMITTED', 'evaluations', '20', NULL, '::1', '2026-08-31 19:19:12');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('315', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '27', '{\"batch_id\":21,\"emp_code\":\"545454\",\"evaluation_date\":\"2026-04-04\"}', '::1', '2026-09-01 01:47:54');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('316', NULL, 'USER_LOGIN_FAILED', 'users', NULL, '{\"username_attempt\":\"\\t kghamdi\"}', '::1', '2026-09-01 01:53:41');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('317', NULL, 'USER_LOGIN_FAILED', 'users', NULL, '{\"username_attempt\":\"\\t kghamdi\"}', '::1', '2026-09-01 01:53:54');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('318', NULL, 'USER_LOGIN_FAILED', 'users', NULL, '{\"username_attempt\":\"\\t kghamdi\"}', '::1', '2026-09-01 01:54:12');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('319', NULL, 'USER_LOGIN_FAILED', 'users', NULL, '{\"username_attempt\":\"kghamdi\"}', '::1', '2026-09-01 01:54:29');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('320', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-09-01 02:00:27');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('321', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '28', '{\"batch_id\":27,\"emp_code\":\"FINAL01\",\"evaluation_date\":\"2026-09-01\"}', NULL, '2026-09-01 03:34:36');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('322', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '29', '{\"batch_id\":27,\"emp_code\":\"EMP8954\",\"evaluation_date\":\"2026-09-01\"}', NULL, '2026-09-01 03:34:36');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('323', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '30', '{\"batch_id\":29,\"emp_code\":\"434\",\"evaluation_date\":\"2026-05-20\"}', '::1', '2026-09-01 03:46:29');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('324', '1', 'TEMPLATE_UPDATE', 'form_templates', '2', NULL, '::1', '2026-09-01 04:12:31');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('325', '1', 'WORKSHOP_REPORT_PRINTED', 'reports', NULL, '{\"level\":\"all\"}', '::1', '2026-09-01 04:26:10');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('326', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '32', '{\"batch_id\":50,\"emp_code\":\"55\",\"evaluation_date\":\"2026-05-20\"}', '::1', '2026-09-01 04:42:43');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('327', '1', 'EMPLOYEE_UPDATE', 'employees', '25', '{\"emp_code\":\"545454\",\"full_name\":\"fh\",\"nickname\":null,\"department_id\":4,\"branch_id\":2,\"manager_id\":2,\"position_id\":8,\"is_active\":1}', '::1', '2026-09-01 05:35:17');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('328', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '33', '{\"batch_id\":53,\"emp_code\":\"FREETEST1\",\"evaluation_date\":\"2026-09-01\"}', NULL, '2026-09-01 05:35:59');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('329', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '34', '{\"batch_id\":53,\"emp_code\":\"FREETEST2\",\"evaluation_date\":\"2026-09-01\"}', NULL, '2026-09-01 05:35:59');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('330', '1', 'EMPLOYEE_UPDATE', 'employees', '14', '{\"emp_code\":\"EMP-014\",\"full_name\":\"بدر علي الخالدي\",\"nickname\":\"يش\",\"department_id\":6,\"branch_id\":3,\"manager_id\":16,\"position_id\":3,\"is_active\":1}', '::1', '2026-09-01 05:37:46');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('331', '1', 'EMPLOYEE_UPDATE', 'employees', '14', '{\"emp_code\":\"EMP-014\",\"full_name\":\"بدر علي الخالدي\",\"nickname\":\"شسس\",\"department_id\":6,\"branch_id\":3,\"manager_id\":16,\"position_id\":3,\"is_active\":1}', '::1', '2026-09-01 05:40:51');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('332', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '35', '{\"batch_id\":54,\"emp_code\":\"232455\",\"evaluation_date\":\"2026-06-02\"}', '::1', '2026-09-01 05:42:57');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('333', '1', 'WORKSHOP_REPORT_PRINTED', 'reports', NULL, '{\"level\":\"all\"}', '::1', '2026-09-01 06:23:44');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('334', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-09-01 14:29:36');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('335', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-09-02 01:28:05');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('336', '1', 'EVALUATION_STARTED', 'evaluations', '36', '{\"evaluated\":\"بدر علي الخالدي\",\"template_id\":2}', '::1', '2026-09-02 01:30:15');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('337', '1', 'EVALUATION_SUBMITTED', 'evaluations', '36', NULL, '::1', '2026-09-02 01:30:41');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('338', '1', 'EVALUATION_STARTED', 'evaluations', '37', '{\"evaluated\":\"بدر علي الخالدي\",\"template_id\":2}', '::1', '2026-09-02 01:32:03');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('339', '1', 'EVALUATION_SUBMITTED', 'evaluations', '37', NULL, '::1', '2026-09-02 01:32:37');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('340', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-09-02 01:57:56');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('341', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-09-02 02:18:13');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('342', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-09-02 02:40:29');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('343', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-09-02 03:19:22');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('344', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-09-02 03:20:32');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('345', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-09-02 03:40:25');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('346', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-09-02 03:50:45');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('347', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-09-02 03:57:56');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('348', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-09-02 04:03:08');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('349', NULL, 'USER_LOGIN_FAILED', 'users', NULL, '{\"username_attempt\":\"tester.eval\"}', '::1', '2026-09-02 05:00:19');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('350', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-09-02 05:00:21');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('351', '1', 'USER_LOGIN_SUCCESS', 'users', '1', '{\"username\":\"sysadmin\"}', '::1', '2026-09-02 05:27:36');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('352', '1', 'EVALUATION_SUBMITTED', 'evaluations', '15', NULL, '::1', '2026-09-02 05:28:30');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('353', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '38', '{\"batch_id\":56,\"emp_code\":\"EMP-005\",\"evaluation_date\":\"2023-06-23\"}', '::1', '2026-09-02 05:41:41');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('354', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '39', '{\"batch_id\":56,\"emp_code\":\"EMP-004\",\"evaluation_date\":\"2023-06-24\"}', '::1', '2026-09-02 05:41:41');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('355', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '40', '{\"batch_id\":56,\"emp_code\":\"EMP-002\",\"evaluation_date\":\"2023-06-25\"}', '::1', '2026-09-02 05:41:41');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('356', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '41', '{\"batch_id\":56,\"emp_code\":\"EMP-001\",\"evaluation_date\":\"2023-06-26\"}', '::1', '2026-09-02 05:41:41');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('357', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '42', '{\"batch_id\":56,\"emp_code\":\"EMP-006\",\"evaluation_date\":\"2023-06-27\"}', '::1', '2026-09-02 05:41:41');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('358', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '43', '{\"batch_id\":56,\"emp_code\":\"EMP-009\",\"evaluation_date\":\"2023-06-28\"}', '::1', '2026-09-02 05:41:41');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('359', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '44', '{\"batch_id\":56,\"emp_code\":\"EMP-003\",\"evaluation_date\":\"2023-06-29\"}', '::1', '2026-09-02 05:41:41');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('360', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '45', '{\"batch_id\":56,\"emp_code\":\"EMP-007\",\"evaluation_date\":\"2023-06-30\"}', '::1', '2026-09-02 05:41:41');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('361', '1', 'EVALUATION_EXCEL_IMPORTED', 'evaluations', '46', '{\"batch_id\":56,\"emp_code\":\"EMP-008\",\"evaluation_date\":\"2023-07-01\"}', '::1', '2026-09-02 05:41:41');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('362', '1', 'EVALUATION_REOPENED', 'evaluations', '40', NULL, '::1', '2026-09-02 05:42:04');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('363', '1', 'WORKSHOP_REPORT_PRINTED', 'reports', '3', '{\"level\":\"branch\"}', '::1', '2026-09-02 05:47:09');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('364', '1', 'USER_UPDATE', 'users', '6', '{\"id\":6,\"username\":\"fzahrani\",\"email\":\"f.zahrani@company.com\",\"employee_id\":6,\"password\":\"123456\"}', '::1', '2026-09-02 05:50:34');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('365', '1', 'USER_UPDATE', 'users', '2', '{\"id\":2,\"username\":\"kghamdi\",\"email\":\"k.ghamdi@company.com\",\"employee_id\":5,\"password\":\"fzahrani\"}', '::1', '2026-09-02 05:50:48');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES ('366', '1', 'USER_UPDATE', 'users', '3', '{\"id\":3,\"username\":\"smutairi\",\"email\":\"s.mutairi@company.com\",\"employee_id\":2,\"password\":\"fzahrani\"}', '::1', '2026-09-02 05:50:58');


-- --------------------------------------------------------
-- Table structure for table `backup_encryption_keys`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `backup_encryption_keys`;
CREATE TABLE `backup_encryption_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_id` int(11) DEFAULT NULL,
  `key_name` varchar(100) DEFAULT NULL,
  `encrypted_key` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_bek_backup` (`backup_id`),
  CONSTRAINT `fk_bek_backup` FOREIGN KEY (`backup_id`) REFERENCES `backup_logs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Data for table `backup_encryption_keys`
--



-- --------------------------------------------------------
-- Table structure for table `backup_health_logs`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `backup_health_logs`;
CREATE TABLE `backup_health_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `check_type` varchar(50) DEFAULT NULL,
  `status` enum('healthy','warning','critical') DEFAULT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `checked_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Data for table `backup_health_logs`
--



-- --------------------------------------------------------
-- Table structure for table `backup_logs`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `backup_logs`;
CREATE TABLE `backup_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `settings_id` int(11) DEFAULT NULL,
  `backup_name` varchar(255) NOT NULL,
  `backup_type` varchar(50) NOT NULL DEFAULT 'full',
  `file_path` text DEFAULT NULL,
  `status` enum('in_progress','success','failed') NOT NULL DEFAULT 'in_progress',
  `progress` int(11) NOT NULL DEFAULT 0,
  `file_size` bigint(20) unsigned DEFAULT NULL,
  `tables_count` int(11) DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  `is_encrypted` tinyint(1) NOT NULL DEFAULT 0,
  `encryption_key` varchar(500) DEFAULT NULL,
  `is_compressed` tinyint(1) NOT NULL DEFAULT 0,
  `compression_ratio` decimal(5,2) DEFAULT NULL,
  `integrity_hash` varchar(128) DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_blog_status_date` (`status`,`created_at`),
  KEY `fk_blog_settings` (`settings_id`),
  KEY `fk_blog_user` (`created_by`),
  CONSTRAINT `fk_blog_settings` FOREIGN KEY (`settings_id`) REFERENCES `backup_settings` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_blog_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Data for table `backup_logs`
--

INSERT INTO `backup_logs` (`id`, `settings_id`, `backup_name`, `backup_type`, `file_path`, `status`, `progress`, `file_size`, `tables_count`, `execution_time`, `is_encrypted`, `encryption_key`, `is_compressed`, `compression_ratio`, `integrity_hash`, `error_message`, `created_by`, `started_at`, `completed_at`, `created_at`) VALUES ('1', NULL, 'incremental_backup_2026-09-01_06-24-29.sql', 'incremental', 'C:/xampp/htdocs/employee-evaluation/backups/incremental_backup_2026-09-01_06-24-29.sql.gz', 'success', '100', '56437', '35', '0', '0', NULL, '1', '0.00', NULL, NULL, '1', '2026-09-01 06:24:29', '2026-09-01 06:24:30', '2026-09-01 06:24:29');
INSERT INTO `backup_logs` (`id`, `settings_id`, `backup_name`, `backup_type`, `file_path`, `status`, `progress`, `file_size`, `tables_count`, `execution_time`, `is_encrypted`, `encryption_key`, `is_compressed`, `compression_ratio`, `integrity_hash`, `error_message`, `created_by`, `started_at`, `completed_at`, `created_at`) VALUES ('2', NULL, 'full_backup_2026-09-02_05-51-27.sql', 'full', 'C:/xampp/htdocs/employee-evaluation/backups/full_backup_2026-09-02_05-51-27.sql.gz', 'success', '100', '59915', '35', '0', '0', NULL, '1', '0.00', NULL, NULL, '1', '2026-09-02 05:51:27', '2026-09-02 05:51:27', '2026-09-02 05:51:27');
INSERT INTO `backup_logs` (`id`, `settings_id`, `backup_name`, `backup_type`, `file_path`, `status`, `progress`, `file_size`, `tables_count`, `execution_time`, `is_encrypted`, `encryption_key`, `is_compressed`, `compression_ratio`, `integrity_hash`, `error_message`, `created_by`, `started_at`, `completed_at`, `created_at`) VALUES ('3', NULL, 'smart_incremental_backup_2026-09-02_05-51-31.sql', 'smart_incremental', '', 'in_progress', '20', NULL, NULL, NULL, '0', NULL, '0', NULL, NULL, NULL, '1', '2026-09-02 05:51:31', NULL, '2026-09-02 05:51:31');


-- --------------------------------------------------------
-- Table structure for table `backup_settings`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `backup_settings`;
CREATE TABLE `backup_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_type` varchar(50) NOT NULL DEFAULT 'full',
  `schedule_type` varchar(20) NOT NULL DEFAULT 'manual',
  `schedule_time` time NOT NULL DEFAULT '02:00:00',
  `schedule_day` tinyint(3) unsigned DEFAULT NULL,
  `retention_days` int(11) NOT NULL DEFAULT 30,
  `encryption_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `compression_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `last_backup` datetime DEFAULT NULL,
  `next_backup` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_bsettings_user` (`created_by`),
  CONSTRAINT `fk_bsettings_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Data for table `backup_settings`
--



-- --------------------------------------------------------
-- Table structure for table `branches`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `branches`;
CREATE TABLE `branches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT 'اسم الفرع (مثل: فرع الرياض)',
  `location` text DEFAULT NULL COMMENT 'وصف موقع الفرع',
  `manager_id` int(11) DEFAULT NULL COMMENT 'معرف الموظف الذي يدير هذا الفرع',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_branch_manager` (`manager_id`),
  CONSTRAINT `fk_branch_manager` FOREIGN KEY (`manager_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='يخزن معلومات الفروع المختلفة للشركة.';

--
-- Data for table `branches`
--



-- --------------------------------------------------------
-- Table structure for table `course_catalog`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `course_catalog`;
CREATE TABLE `course_catalog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL COMMENT 'عنوان الدورة الرسمي',
  `description` text DEFAULT NULL COMMENT 'وصف مختصر للدورة وأهدافها',
  `category` varchar(100) DEFAULT NULL COMMENT 'تصنيف الدورة (إدارية, فنية, سلامة, ...)',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`),
  KEY `fk_course_catalog_user` (`created_by`),
  CONSTRAINT `fk_course_catalog_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Data for table `course_catalog`
--



-- --------------------------------------------------------
-- Table structure for table `course_evaluations`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `course_evaluations`;
CREATE TABLE `course_evaluations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `expected_attendees` int(11) NOT NULL COMMENT 'عدد الحضور المفترض',
  `actual_attendees` int(11) NOT NULL COMMENT 'عدد الحضور الفعلي',
  `program_regularity_weighted_score` decimal(4,2) NOT NULL COMMENT 'درجة انتظام البرنامج (المدخلة مباشرة من 0.00 إلى 30.00)',
  `participant_comprehension_weighted_score` decimal(4,2) NOT NULL COMMENT 'درجة استيعاب المشاركين (المدخلة مباشرة من 0.00 إلى 20.00)',
  `final_score` decimal(5,2) DEFAULT NULL COMMENT 'النتيجة النهائية المجمعة',
  `notes` text DEFAULT NULL,
  `evaluated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `course_id` (`course_id`),
  KEY `evaluated_by` (`evaluated_by`),
  CONSTRAINT `course_evaluations_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `training_courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `course_evaluations_ibfk_2` FOREIGN KEY (`evaluated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_eval_training_course` FOREIGN KEY (`course_id`) REFERENCES `training_courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Data for table `course_evaluations`
--

INSERT INTO `course_evaluations` (`id`, `course_id`, `expected_attendees`, `actual_attendees`, `program_regularity_weighted_score`, `participant_comprehension_weighted_score`, `final_score`, `notes`, `evaluated_by`, `created_at`) VALUES ('1', '1', '12', '11', '92.50', '88.00', '90.25', 'تفاعل ممتاز من المشاركين وتم تغطية كامل المحتوى.', '1', '2026-08-24 03:29:48');
INSERT INTO `course_evaluations` (`id`, `course_id`, `expected_attendees`, `actual_attendees`, `program_regularity_weighted_score`, `participant_comprehension_weighted_score`, `final_score`, `notes`, `evaluated_by`, `created_at`) VALUES ('2', '2', '15', '13', '85.00', '82.40', '83.70', 'احتياج لبعض التمارين العملية الإضافية.', '6', '2026-08-24 03:29:48');


-- --------------------------------------------------------
-- Table structure for table `criteria`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `criteria`;
CREATE TABLE `criteria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL COMMENT 'معرف القالب الذي ينتمي إليه هذا المعيار.',
  `criterion_name` varchar(255) NOT NULL COMMENT 'اسم المعيار الرئيسي (مثل: جودة العمل، المهارات القيادية).',
  `criterion_description` text DEFAULT NULL COMMENT 'وصف إضافي للمعيار لتوضيح ما يقيسه.',
  `criterion_weight` decimal(5,2) NOT NULL DEFAULT 0.00 COMMENT 'الوزن النسبي للمعيار في إجمالي درجة الاستمارة.',
  `override_summary_settings` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'هل هذا المعيار يتجاوز إعدادات الملخص الافتراضية؟ (1=نعم).',
  `summary_configuration` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'إعدادات أعمدة الملخص المخصصة لهذا المعيار فقط (إذا كان التجاوز فعالاً).' CHECK (json_valid(`summary_configuration`)),
  `order_index` int(11) DEFAULT 0 COMMENT 'لتحديد ترتيب ظهور المعايير في الاستمارة.',
  PRIMARY KEY (`id`),
  KEY `template_id` (`template_id`),
  CONSTRAINT `criteria_ibfk_1` FOREIGN KEY (`template_id`) REFERENCES `form_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='يخزن المعايير الرئيسية التي تتكون منها كل استمارة.';

--
-- Data for table `criteria`
--

INSERT INTO `criteria` (`id`, `template_id`, `criterion_name`, `criterion_description`, `criterion_weight`, `override_summary_settings`, `summary_configuration`, `order_index`) VALUES ('1', '1', 'الكفاءة الفنية والمعرفة بالعمل', 'تقييم جودة العمل وسرعة الإنجاز وإتقان أدوات العمل', '30.00', '0', NULL, '1');
INSERT INTO `criteria` (`id`, `template_id`, `criterion_name`, `criterion_description`, `criterion_weight`, `override_summary_settings`, `summary_configuration`, `order_index`) VALUES ('2', '1', 'التعاون والعمل الجماعي', 'تقييم روح الفريق والتواصل الفعال مع الزملاء', '25.00', '0', NULL, '2');
INSERT INTO `criteria` (`id`, `template_id`, `criterion_name`, `criterion_description`, `criterion_weight`, `override_summary_settings`, `summary_configuration`, `order_index`) VALUES ('3', '1', 'الالتزام والانضباط الوظيفي', 'تقييم الالتزام بمواعيد العمل والمهام الموكلة', '25.00', '0', NULL, '3');
INSERT INTO `criteria` (`id`, `template_id`, `criterion_name`, `criterion_description`, `criterion_weight`, `override_summary_settings`, `summary_configuration`, `order_index`) VALUES ('4', '1', 'المبادرة والتطوير الذاتي', 'تقييم المشاركة في التدريب والمرونة وتقديم الحلول', '20.00', '0', NULL, '4');
INSERT INTO `criteria` (`id`, `template_id`, `criterion_name`, `criterion_description`, `criterion_weight`, `override_summary_settings`, `summary_configuration`, `order_index`) VALUES ('8', '2', 'أولاً: تطبيق المهام اليومية', '????? G3:L5', '40.00', '0', NULL, '1');
INSERT INTO `criteria` (`id`, `template_id`, `criterion_name`, `criterion_description`, `criterion_weight`, `override_summary_settings`, `summary_configuration`, `order_index`) VALUES ('9', '2', 'ثانياً: رفع التقرير الأسبوعي', 'M:P', '30.00', '0', NULL, '2');
INSERT INTO `criteria` (`id`, `template_id`, `criterion_name`, `criterion_description`, `criterion_weight`, `override_summary_settings`, `summary_configuration`, `order_index`) VALUES ('10', '2', 'ثالثاً: رفع التقرير الشهري', 'Q:R', '30.00', '0', NULL, '3');


-- --------------------------------------------------------
-- Table structure for table `criteria_sections`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `criteria_sections`;
CREATE TABLE `criteria_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `criterion_id` int(11) NOT NULL COMMENT 'معرف المعيار الذي يتبعه هذا القسم.',
  `section_name` varchar(255) NOT NULL COMMENT 'اسم القسم أو السؤال الفعلي (مثل: الدقة في إنجاز المهام).',
  `section_description` text DEFAULT NULL COMMENT 'وصف إضافي للقسم أو إرشادات للمقيّم.',
  `evaluation_type` enum('percentage','numeric','grade','boolean','scale','text','multiple_choice') NOT NULL COMMENT 'نوع حقل الإدخال الذي سيظهر للمقيّم.',
  `evaluation_options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'يخزن خيارات التقييم كـ JSON (لأنواع مثل grade و multiple_choice).' CHECK (json_valid(`evaluation_options`)),
  `min_value` decimal(10,2) DEFAULT NULL COMMENT 'القيمة الدنيا للحقول الرقمية أو المقياس.',
  `max_value` decimal(10,2) DEFAULT NULL COMMENT 'القيمة القصوى للحقول الرقمية أو المقياس.',
  `section_weight` decimal(5,2) NOT NULL DEFAULT 0.00 COMMENT 'الوزن النسبي للقسم داخل معياره الأب.',
  `allow_notes` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'هل يُسمح للمقيّم بإضافة ملاحظات نصية لهذا القسم؟ (1=نعم).',
  `notes_required` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'هل الملاحظات إجبارية إذا تم السماح بها؟ (1=نعم).',
  `notes_placeholder` varchar(255) DEFAULT NULL COMMENT 'النص التلميحي الذي يظهر في حقل الملاحظات.',
  `order_index` int(11) DEFAULT 0 COMMENT 'ترتيب ظهور الأقسام داخل المعيار.',
  PRIMARY KEY (`id`),
  KEY `criterion_id` (`criterion_id`),
  CONSTRAINT `criteria_sections_ibfk_1` FOREIGN KEY (`criterion_id`) REFERENCES `criteria` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='يخزن الأقسام التفصيلية والأسئلة الفعلية لكل معيار.';

--
-- Data for table `criteria_sections`
--

INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('1', '1', 'جودة العمل المنجز', 'مدى دقة وجودة المخرجات', 'numeric', NULL, '1.00', '10.00', '40.00', '1', '0', 'ملاحظات حول جودة العمل', '1');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('2', '1', 'سرعة إنجاز المهام', 'نسبة الالتزام بالمواعيد المحددة للمهام', 'percentage', NULL, '0.00', '100.00', '30.00', '1', '0', 'ملاحظات حول سرعة الإنجاز', '2');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('3', '1', 'إتقان أدوات العمل', 'المستوى العام في استخدام أدوات وأنظمة العمل', 'grade', '[{\"label\":\"ممتاز\",\"value\":95},{\"label\":\"جيد جداً\",\"value\":85},{\"label\":\"جيد\",\"value\":75},{\"label\":\"مقبول\",\"value\":65}]', NULL, NULL, '30.00', '1', '0', NULL, '3');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('4', '2', 'روح الفريق', 'المشاركة الفاعلة ودعم الزملاء', 'grade', '[{\"label\":\"ممتاز\",\"value\":95},{\"label\":\"جيد جداً\",\"value\":85},{\"label\":\"جيد\",\"value\":75},{\"label\":\"مقبول\",\"value\":65}]', NULL, NULL, '60.00', '1', '0', NULL, '1');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('5', '2', 'فعالية التواصل', 'وضوح التواصل مع الزملاء والإدارة', 'grade', '[{\"label\":\"ممتاز\",\"value\":95},{\"label\":\"جيد جداً\",\"value\":85},{\"label\":\"جيد\",\"value\":75},{\"label\":\"مقبول\",\"value\":65}]', NULL, NULL, '40.00', '1', '0', NULL, '2');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('6', '3', 'الالتزام بمواعيد العمل', 'نسبة الحضور والانضباط في الدوام', 'percentage', NULL, '0.00', '100.00', '50.00', '1', '0', NULL, '1');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('7', '3', 'إنجاز المهام الموكلة', 'مدى الالتزام بتنفيذ المهام المطلوبة', 'numeric', NULL, '1.00', '10.00', '50.00', '1', '0', NULL, '2');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('8', '4', 'المشاركة في برامج التدريب', 'نسبة حضور البرامج التدريبية المتاحة', 'numeric', NULL, '0.00', '100.00', '50.00', '1', '0', NULL, '1');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('9', '4', 'اقتراح حلول مبتكرة', 'تقديم مقترحات تطويرية خلال الفترة', 'grade', '[{\"label\":\"نعم\",\"value\":100},{\"label\":\"لا\",\"value\":0}]', NULL, NULL, '30.00', '1', '0', NULL, '2');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('10', '4', 'المرونة في استلام مهام جديدة', 'الاستعداد لتولي مهام خارج النطاق المعتاد', 'numeric', NULL, '1.00', '10.00', '20.00', '1', '0', NULL, '3');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('20', '8', 'الإلتزام بالزي الرسمي', '', 'grade', '[{\"label\":\"طبق\",\"value\":100},{\"label\":\"لم يطبق\",\"value\":0}]', NULL, '30.00', '33.34', '1', '0', '???????...', '1');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('21', '8', 'التوجيهات المقدمه له', '', 'grade', '[{\"label\":\"طبق\",\"value\":100},{\"label\":\"لم يطبق\",\"value\":0}]', NULL, '30.00', '33.33', '1', '0', '???????...', '2');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('22', '8', 'تعامله مع الوثائق المقدمه له', '', 'grade', '[{\"label\":\"قرأ\",\"value\":100},{\"label\":\"لم يقرأ\",\"value\":0}]', NULL, '30.00', '33.33', '1', '0', '???????...', '3');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('23', '9', 'الأسبوع الأول', '', 'grade', '[{\"label\":\"رفع\",\"value\":100},{\"label\":\"لم يرفع\",\"value\":0}]', NULL, NULL, '25.00', '0', '0', 'اكتب ملاحظاتك هنا...', '1');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('24', '9', 'الأسبوع الثاني', '', 'grade', '[{\"label\":\"رفع\",\"value\":100},{\"label\":\"لم يرفع\",\"value\":0}]', NULL, NULL, '25.00', '0', '0', 'اكتب ملاحظاتك هنا...', '2');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('25', '9', 'الأسبوع الثالث', '', 'grade', '[{\"label\":\"رفع\",\"value\":100},{\"label\":\"لم يرفع\",\"value\":0}]', NULL, NULL, '25.00', '0', '0', 'اكتب ملاحظاتك هنا...', '3');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('26', '9', 'الأسبوع الرابع', '', 'grade', '[{\"label\":\"رفع\",\"value\":100},{\"label\":\"لم يرفع\",\"value\":0}]', NULL, NULL, '25.00', '0', '0', 'اكتب ملاحظاتك هنا...', '4');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('27', '10', 'الرفع', '', 'grade', '[{\"label\":\"رفع\",\"value\":100},{\"label\":\"لم يرفع\",\"value\":0}]', NULL, NULL, '50.00', '0', '0', 'اكتب ملاحظاتك هنا...', '1');
INSERT INTO `criteria_sections` (`id`, `criterion_id`, `section_name`, `section_description`, `evaluation_type`, `evaluation_options`, `min_value`, `max_value`, `section_weight`, `allow_notes`, `notes_required`, `notes_placeholder`, `order_index`) VALUES ('28', '10', 'استخدام النموذج الرسمي', '', 'grade', '[{\"label\":\"إلتزم\",\"value\":100},{\"label\":\"لم يلتزم\",\"value\":0}]', NULL, NULL, '50.00', '0', '0', 'اكتب ملاحظاتك هنا...', '2');


-- --------------------------------------------------------
-- Table structure for table `csrf_tokens`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `csrf_tokens`;
CREATE TABLE `csrf_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token` varchar(191) NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_csrf_token_user` (`token`,`user_id`),
  KEY `idx_csrf_expires` (`expires_at`),
  KEY `fk_csrf_user` (`user_id`),
  CONSTRAINT `fk_csrf_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Data for table `csrf_tokens`
--

INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('1', '1', 'd55281b5ff50adde290be3a6d113ee1196489d5c58d96facfb0535bac43154e6', '0', '2026-08-24 04:43:17', '2026-08-24 03:43:17');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('2', '1', '79369453ae1bfaa47a6c1062dadd2669040050160b9d7cf0eecf4f7d88907c98', '0', '2026-08-24 04:47:10', '2026-08-24 03:47:10');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('3', '1', '97810c5d1a609e9b045cf0e92d1e310f26c3dc5f4d1d6833c1030d9ae12fb7f6', '0', '2026-08-24 04:47:31', '2026-08-24 03:47:31');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('4', '1', '749eafc0efd9a6970c90799752d3bf6157f2500c2b090e5397c269d35817b463', '0', '2026-08-24 04:48:43', '2026-08-24 03:48:43');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('5', '1', 'c42f90e50cb2053d3486596b1fb218e82c2bc6e01c9f66ac53b660a65937dc8c', '0', '2026-08-24 04:48:56', '2026-08-24 03:48:56');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('6', '1', 'f3cb430a7e91cfefcaf164edd53a9c82674668861ebb6a961863d3a7ea51e569', '0', '2026-08-24 04:55:32', '2026-08-24 03:55:32');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('7', '1', '107354877cb624548f8740b7a8d565d48ecb75466094b2c878d8067014618260', '0', '2026-08-24 04:56:31', '2026-08-24 03:56:31');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('8', '1', 'cb507ee18b7479c623611dfadcf66ecf40902bd5de8b7a26d3a81b71c92ef9c1', '0', '2026-08-24 04:56:31', '2026-08-24 03:56:31');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('9', '1', '8cbf8580d209e2f2c0cb29ce03a49ce14c412369d591a77414660c5b6a10a473', '0', '2026-08-24 05:14:51', '2026-08-24 04:14:51');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('10', '1', 'c5911fb16861ff08d75919dc1758204bf29ee45226da023b8b6d62b401a0748c', '0', '2026-08-24 05:14:51', '2026-08-24 04:14:51');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('11', '1', '788cef18b85bbad23d6122546e0e8d961facde1359482f80fd079a7a25f364be', '0', '2026-08-24 05:14:51', '2026-08-24 04:14:51');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('12', '1', '1df86d4871a9038290787a5b3caeed358665502d6e82c02fab11c20c117d8d1b', '0', '2026-08-24 05:14:51', '2026-08-24 04:14:51');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('13', '1', '75f6c55b2204676b0258281838acd79b00b046766a0ea2bf0e0b810e1f854ca8', '0', '2026-08-24 05:15:25', '2026-08-24 04:15:25');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('14', '1', '2ec2fcb18a93816a6f487811e368ee1f8bcdb6b36ff70ff4595bd9dd75d27976', '0', '2026-08-24 05:15:42', '2026-08-24 04:15:42');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('15', '1', '0ad85a41f071cb8ca5e04f43e27f05927ff202d9e29b7ecccfe70c43e7747863', '0', '2026-08-24 05:15:57', '2026-08-24 04:15:57');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('16', '1', '0200c3f04a0db30a5871c3c72c56ea2f79a68b36599ed88c7d1e370e4d7b10d4', '0', '2026-08-24 05:15:57', '2026-08-24 04:15:57');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('17', '1', '77f7db563642f15bb030703c8b09955d9398fa0d5054739784df9056e623a9c7', '0', '2026-08-24 05:15:57', '2026-08-24 04:15:57');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('18', '1', 'b53ddbc5e9e2dd8c31b69d7f94328213036ea48401b0153baa85b37afcc8b61e', '0', '2026-08-24 05:20:44', '2026-08-24 04:20:44');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('19', '1', 'c0038349004b6709ddad63838713a28ca6aa1a06d0217b6ee6e5636c73526967', '0', '2026-08-24 05:20:44', '2026-08-24 04:20:44');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('20', '1', '32fb5935b5c68b042ec5f4f76468b12213fd165420ecde4a3180397989296f44', '0', '2026-08-24 05:20:44', '2026-08-24 04:20:44');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('21', '1', '796dee6c4af127f86dcc344005365c11122808935a1bfb5cfb05c16bdf221bee', '0', '2026-08-24 05:20:44', '2026-08-24 04:20:44');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('22', '1', 'e343aa0e5f55d49e7e01af46aaf83b03f5784c4523adcee873561ab646956029', '0', '2026-08-24 06:03:55', '2026-08-24 05:03:55');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('23', '1', '11a27358de19d7235d5ba9dde16a111767257d531318411ceffe319dcb2c9cac', '0', '2026-08-31 04:03:54', '2026-08-31 03:03:54');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('24', '1', '39bade2b54371d1a4a9a19cc8a7acaf6f417a542d18c1e450ecf89080f1a93af', '0', '2026-08-31 04:06:59', '2026-08-31 03:06:59');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('25', '1', '715ec880bf6d17b7e70095d8dcd043cc217cdade51403c9454951a68fba2bbb1', '0', '2026-08-31 04:39:08', '2026-08-31 03:39:08');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('26', '1', '2cdb150510c37f3dae10c51961a37b1d1974b82cfddbe02907979cbc690798f5', '0', '2026-08-31 04:52:37', '2026-08-31 03:52:37');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('27', '1', 'da412e03ba8495e0063b841b78e12794f253cd5bdaebca090101b1f6fac4d8f0', '0', '2026-08-31 04:53:41', '2026-08-31 03:53:41');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('28', '1', 'b02e6145533c7264d81f760ae35844ea9ae0e243afb47c6f7f03ae1588867723', '0', '2026-08-31 04:57:16', '2026-08-31 03:57:16');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('29', '1', 'db7825e857868a19a20084ac473161c1f60e005c36d534c3cbc4ad86cdcb1f4a', '0', '2026-08-31 05:03:33', '2026-08-31 04:03:33');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('30', '1', '7ea519b9068a3b63ed6f7ab1a09c7d9d31e4e1a466b6583a1d44dca3c239106f', '0', '2026-08-31 05:26:40', '2026-08-31 04:26:40');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('31', '1', 'f9b7caf178e22c8c28ffb04e7d923d4d32e234d9059d13aeb2e41651a272a4fb', '0', '2026-08-31 20:15:20', '2026-08-31 19:15:20');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('32', '1', 'd64d6e4c83d858a5f9912f8e17cbf7ee16d686ef1020814a44d1afd739275387', '0', '2026-09-01 02:45:23', '2026-09-01 01:45:23');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('33', '1', 'efa196f6ad20cf4935866098afb3a5ab976c11d42f0342e695bb4b58b49ec71e', '0', '2026-09-01 03:00:27', '2026-09-01 02:00:27');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('34', '1', 'a2e2b6408dc623c133957bebf5fcdb8fb89c3770f6084ee960e5e46fa5b4d745', '0', '2026-09-01 04:36:51', '2026-09-01 03:36:51');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('35', '1', 'a6f25eea777139fe97b15bb8a6278c4873adc3114e61c265796cb686f2eb8560', '0', '2026-09-01 05:38:34', '2026-09-01 04:38:34');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('36', '1', '0b1dd6949169445820f1cd2852f2fa9a9b117f0570df1b5783521501be742fa5', '0', '2026-09-01 07:39:07', '2026-09-01 05:39:07');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('37', '1', '278c2b71f09a88df3e5a006ded81684dde17d3b705e0c5f6f91795c4e2c43d21', '0', '2026-09-01 16:29:36', '2026-09-01 14:29:36');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('38', '1', 'de069adb8eea95a2d15fd729f3bc6c7588c2658ece1d732adce5af46dec0139e', '0', '2026-09-02 03:28:05', '2026-09-02 01:28:05');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('39', '1', '301f8168dcb67b3f0244d674bd8ca6c87dc3f1209feec8bd004b6b5629dc9bf3', '0', '2026-09-02 03:57:52', '2026-09-02 01:57:52');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('40', '1', '2cf9b478b5b33edbacc970ea7eca7b481833efe39e9b1517f939b448b44a96d9', '0', '2026-09-02 03:57:56', '2026-09-02 01:57:56');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('41', '1', 'fa0928ba4c7bcff6d4f304b9e0c9b5349f78c6bc5562cb62af4826cd86fdce66', '0', '2026-09-02 04:18:10', '2026-09-02 02:18:10');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('42', '1', 'a2909f772483214113aa5e42907ee57f81e4cf3da6c62c6405573a67f393d28b', '0', '2026-09-02 04:18:13', '2026-09-02 02:18:13');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('43', '1', 'db72157330284f99f4035501ad049194fefd9b358a9794da7662829c5d842848', '0', '2026-09-02 04:40:22', '2026-09-02 02:40:22');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('44', '1', '103eb6cd1d1fb537405370d66f084690af3d7169d78f5fe70138145fe6fa62c6', '0', '2026-09-02 04:40:29', '2026-09-02 02:40:29');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('45', '1', '10bf4ec6017ef920a4de32008e68e3183669969b4c9f07dfa7454b89d849c256', '0', '2026-09-02 05:19:22', '2026-09-02 03:19:22');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('46', '1', '9885c4168af38617c713229a62e30f85a183833f3472a39e8ccbe26be05b1e88', '0', '2026-09-02 05:20:32', '2026-09-02 03:20:32');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('47', '1', '683e8a857b740c200e69d5bb1916375a91daaa1a1acd0593cd72768f30c203aa', '0', '2026-09-02 05:40:22', '2026-09-02 03:40:22');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('48', '1', '15a1ed20be42144d87df1fd4f4c78f96990ef1983f5ea22f224458a280ac961e', '0', '2026-09-02 05:40:25', '2026-09-02 03:40:25');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('49', '1', '3a3c086094c80c7cbe65c1e8171b837543784797cc22ce0fc30e8e00f86e6a0b', '0', '2026-09-02 05:48:45', '2026-09-02 03:48:45');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('50', '1', '49d41abca2a390e5b7f37c1a296bf2f7a5edbc755a45378b619d9c539bf6bff1', '0', '2026-09-02 05:50:45', '2026-09-02 03:50:45');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('51', '1', 'e3c1f78fad5f0108ec389d7366049d27c8fa07624a7e0c060553a7f680b2d081', '0', '2026-09-02 05:57:53', '2026-09-02 03:57:53');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('52', '1', '4000f373e7337d4300b144e38031ee9f5b08d29506691fb1d2b5f352078c4863', '0', '2026-09-02 05:57:56', '2026-09-02 03:57:56');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('53', '1', '83e69cec2065e380f5696c1bf57c2a74f763f7b1b3ab58ad5875b7d2eb789e1b', '0', '2026-09-02 06:03:04', '2026-09-02 04:03:04');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('54', '1', '7e373aab65b84795e763e66072b788955ee33af7e793417287e66b6884b4d64f', '0', '2026-09-02 06:03:08', '2026-09-02 04:03:08');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('55', '1', '3ffee4f689f54c2e69388c585285965ea2dc84ef11713458c53b9383bea8b0ee', '0', '2026-09-02 06:19:10', '2026-09-02 04:19:10');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('57', '1', 'c9930f76fc76bbf87e5e7fae970da55672b3e5632f6f1fe7849fb8e5a2de4be4', '0', '2026-09-02 07:00:22', '2026-09-02 05:00:22');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('58', '1', '9d61853ca5ae67604dc10b408b131383bc79bb07cce9712771e286a38a0e4a5f', '0', '2026-09-02 07:27:16', '2026-09-02 05:27:16');
INSERT INTO `csrf_tokens` (`id`, `user_id`, `token`, `used`, `expires_at`, `created_at`) VALUES ('59', '1', 'e1c197b0a97978c75240426e3259dfb0c5d1ce1be64e0ccf14f7b2bbe8f7b28e', '0', '2026-09-02 07:27:36', '2026-09-02 05:27:36');


-- --------------------------------------------------------
-- Table structure for table `departments`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT 'اسم القسم (مثل: المبيعات، الدعم الفني)',
  `branch_id` int(11) DEFAULT NULL COMMENT 'معرف الفرع الذي يتبعه القسم. إذا كان NULL، فهو قسم مركزي يتبع الشركة الأم.',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`),
  CONSTRAINT `departments_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='يخزن معلومات الأقسام داخل الفروع أو الشركة الأم.';

--
-- Data for table `departments`
--



-- --------------------------------------------------------
-- Table structure for table `employees`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `employees`;
CREATE TABLE `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_code` varchar(50) NOT NULL COMMENT 'الرقم الوظيفي الفريد للموظف',
  `full_name` varchar(255) NOT NULL COMMENT 'الاسم الكامل للموظف',
  `nickname` varchar(255) DEFAULT NULL COMMENT '???? ?? ??? ?????? (???????)',
  `personal_email` varchar(255) DEFAULT NULL COMMENT 'البريد الإلكتروني الشخصي للموظف (للتواصل غير الرسمي)',
  `phone` varchar(20) DEFAULT NULL COMMENT 'رقم هاتف الموظف',
  `join_date` date DEFAULT NULL COMMENT 'تاريخ انضمام الموظف للشركة',
  `department_id` int(11) DEFAULT NULL COMMENT 'معرف القسم الذي يعمل به الموظف',
  `branch_id` int(11) DEFAULT NULL COMMENT 'معرف الفرع الذي يعمل به الموظف',
  `manager_id` int(11) DEFAULT NULL COMMENT 'معرف المدير المباشر للموظف (علاقة ذاتية)',
  `position_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'هل الموظف حالي في الشركة (1=نعم, 0=لا)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `emp_code` (`emp_code`),
  UNIQUE KEY `personal_email` (`personal_email`),
  KEY `department_id` (`department_id`),
  KEY `branch_id` (`branch_id`),
  KEY `manager_id` (`manager_id`),
  KEY `position_id` (`position_id`),
  CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `employees_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `employees_ibfk_3` FOREIGN KEY (`manager_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `employees_ibfk_4` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='يحتوي على بيانات الموارد البشرية للموظفين (كيانات تنظيمية).';

--
-- Data for table `employees`
--



-- --------------------------------------------------------
-- Table structure for table `evaluation_answers`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `evaluation_answers`;
CREATE TABLE `evaluation_answers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `evaluation_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `raw_value` text DEFAULT NULL,
  `normalized_score` decimal(5,2) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `evaluation_id` (`evaluation_id`),
  KEY `section_id` (`section_id`),
  CONSTRAINT `ans_fk_evaluation` FOREIGN KEY (`evaluation_id`) REFERENCES `evaluations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ans_fk_section` FOREIGN KEY (`section_id`) REFERENCES `criteria_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Data for table `evaluation_answers`
--

INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('128', '1', '1', '9.00', '88.89', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('129', '2', '1', '9.00', '88.89', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('130', '3', '1', '6.00', '55.56', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('131', '4', '1', '9.00', '88.89', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('132', '5', '1', '8.00', '77.78', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('133', '6', '1', '7.00', '66.67', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('134', '7', '1', '9.00', '88.89', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('135', '8', '1', '8.00', '77.78', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('136', '9', '1', '6.00', '55.56', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('137', '10', '1', '5.00', '44.44', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('138', '11', '1', '9.00', '88.89', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('139', '12', '1', '9.00', '88.89', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('140', '1', '2', '92', '91.50', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('141', '2', '2', '95', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('142', '3', '2', '65', '64.75', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('143', '4', '2', '98', '98.25', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('144', '5', '2', '87', '87.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('145', '6', '2', '77', '76.50', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('146', '7', '2', '93', '93.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('147', '8', '2', '81', '81.25', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('148', '9', '2', '69', '69.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('149', '10', '2', '59', '58.50', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('150', '11', '2', '91', '90.75', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('151', '12', '2', '96', '96.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('152', '1', '3', '85', '85.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('153', '2', '3', '95', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('154', '3', '3', '65', '65.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('155', '4', '3', '95', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('156', '5', '3', '85', '85.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('157', '6', '3', '75', '75.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('158', '7', '3', '95', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('159', '8', '3', '75', '75.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('160', '9', '3', '65', '65.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('161', '10', '3', '65', '65.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('162', '11', '3', '85', '85.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('163', '12', '3', '95', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('164', '1', '4', '85', '85.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('165', '2', '4', '95', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('166', '3', '4', '65', '65.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('167', '4', '4', '95', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('168', '5', '4', '85', '85.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('169', '6', '4', '75', '75.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('170', '7', '4', '95', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('171', '8', '4', '75', '75.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('172', '9', '4', '65', '65.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('173', '10', '4', '65', '65.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('174', '11', '4', '85', '85.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('175', '12', '4', '95', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('176', '1', '5', '85', '85.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('177', '2', '5', '95', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('178', '3', '5', '65', '65.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('179', '4', '5', '95', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('180', '5', '5', '85', '85.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('181', '6', '5', '75', '75.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('182', '7', '5', '95', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('183', '8', '5', '75', '75.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('184', '9', '5', '65', '65.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('185', '10', '5', '65', '65.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('186', '11', '5', '85', '85.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('187', '12', '5', '95', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('188', '1', '6', '87', '86.50', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('189', '2', '6', '90', '90.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('190', '3', '6', '60', '59.75', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('191', '4', '6', '93', '93.25', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('192', '5', '6', '82', '82.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('193', '6', '6', '72', '71.50', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('194', '7', '6', '88', '88.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('195', '8', '6', '76', '76.25', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('196', '9', '6', '64', '64.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('197', '10', '6', '54', '53.50', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('198', '11', '6', '86', '85.75', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('199', '12', '6', '91', '91.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('200', '1', '7', '9.00', '88.89', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('201', '2', '7', '9.00', '88.89', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('202', '3', '7', '6.00', '55.56', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('203', '4', '7', '10.00', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('204', '5', '7', '9.00', '88.89', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('205', '6', '7', '8.00', '77.78', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('206', '7', '7', '9.00', '88.89', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('207', '8', '7', '8.00', '77.78', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('208', '9', '7', '7.00', '66.67', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('209', '10', '7', '6.00', '55.56', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('210', '11', '7', '9.00', '88.89', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('211', '12', '7', '10.00', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('212', '1', '8', '9.00', '9.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('213', '2', '8', '9.00', '9.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('214', '3', '8', '6.00', '6.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('215', '4', '8', '9.00', '9.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('216', '5', '8', '8.00', '8.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('217', '6', '8', '7.00', '7.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('218', '7', '8', '9.00', '9.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('219', '8', '8', '8.00', '8.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('220', '9', '8', '6.00', '6.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('221', '10', '8', '5.00', '5.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('222', '11', '8', '9.00', '9.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('223', '12', '8', '9.00', '9.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('224', '1', '9', '85', '85.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('225', '2', '9', '95', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('226', '3', '9', '65', '65.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('227', '4', '9', '95', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('228', '5', '9', '85', '85.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('229', '6', '9', '75', '75.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('230', '7', '9', '95', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('231', '8', '9', '75', '75.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('232', '9', '9', '65', '65.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('233', '10', '9', '65', '65.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('234', '11', '9', '85', '85.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('235', '12', '9', '95', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('236', '1', '10', '9.00', '88.89', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('237', '2', '10', '10.00', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('238', '3', '10', '7.00', '66.67', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('239', '4', '10', '10.00', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('240', '5', '10', '9.00', '88.89', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('241', '6', '10', '8.00', '77.78', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('242', '7', '10', '10.00', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('243', '8', '10', '8.00', '77.78', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('244', '9', '10', '7.00', '66.67', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('245', '10', '10', '6.00', '55.56', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('246', '11', '10', '9.00', '88.89', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('247', '12', '10', '10.00', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('248', '18', '1', '9', '88.89', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('249', '18', '2', '21', '21.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('250', '18', '3', '95', '95.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('251', '18', '4', '95', '95.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('252', '18', '5', '95', '95.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('253', '18', '6', '12', '12.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('254', '18', '7', '9', '88.89', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('255', '18', '8', '22', '22.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('256', '18', '9', '100', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('257', '18', '10', '10', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('258', '19', '1', '7', '66.67', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('259', '19', '2', '85', '85.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('260', '19', '3', 'ممتاز', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('261', '19', '4', 'ممتاز', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('262', '19', '5', 'جيد', '75.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('263', '19', '6', '90', '90.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('264', '19', '7', '8', '77.78', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('265', '19', '8', '75', '75.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('266', '19', '9', 'نعم', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('267', '19', '10', '6', '55.56', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('278', '21', '1', '10', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('279', '21', '2', '10', '10.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('280', '21', '3', 'ممتاز', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('281', '21', '4', 'ممتاز', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('282', '21', '5', 'ممتاز', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('283', '21', '6', '10', '10.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('284', '21', '7', '10', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('285', '21', '8', '10', '10.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('286', '21', '9', 'لا', '0.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('287', '21', '10', '10', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('288', '22', '1', '10', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('289', '22', '2', '10', '10.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('290', '22', '3', 'ممتاز', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('291', '22', '4', 'ممتاز', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('292', '22', '5', 'ممتاز', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('293', '22', '6', '10', '10.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('294', '22', '7', '10', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('295', '22', '8', '10', '10.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('296', '22', '9', 'لا', '0.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('297', '22', '10', '10', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('298', '23', '1', '7', '66.67', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('299', '23', '2', '85', '85.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('300', '23', '3', 'ممتاز', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('301', '23', '4', 'ممتاز', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('302', '23', '5', 'جيد', '75.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('303', '23', '6', '90', '90.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('304', '23', '7', '8', '77.78', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('305', '23', '8', '75', '75.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('306', '23', '9', 'نعم', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('307', '23', '10', '6', '55.56', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('311', '25', '1', '10', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('312', '25', '2', '10', '10.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('313', '25', '3', 'ممتاز', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('314', '25', '4', 'ممتاز', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('315', '25', '5', 'ممتاز', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('316', '25', '6', '10', '10.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('317', '25', '7', '10', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('318', '25', '8', '10', '10.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('319', '25', '9', 'نعم', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('320', '25', '10', '10', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('321', '26', '1', '10', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('322', '26', '2', '10', '10.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('323', '26', '3', 'جيد جداً', '85.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('324', '26', '4', 'جيد جداً', '85.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('325', '26', '5', 'جيد جداً', '85.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('326', '26', '6', '100', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('327', '26', '7', '10', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('328', '26', '8', '100', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('329', '26', '9', 'نعم', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('330', '26', '10', '10', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('331', '20', '1', '5', '44.44', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('332', '20', '2', '70', '70.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('333', '20', '3', '95', '95.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('334', '20', '4', '95', '95.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('335', '20', '5', '95', '95.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('336', '20', '6', '80', '80.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('337', '20', '7', '6', '55.56', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('338', '20', '8', '60', '60.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('339', '20', '9', '0', '0.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('340', '20', '10', '10', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('341', '27', '1', '10', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('342', '27', '2', '10', '10.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('343', '27', '3', 'ممتاز', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('344', '27', '4', 'ممتاز', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('345', '27', '5', 'ممتاز', '95.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('346', '27', '6', '100', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('347', '27', '7', '10', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('348', '27', '8', '10', '10.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('349', '27', '9', 'نعم', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('350', '27', '10', '10', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('370', '32', '20', '30.00', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('371', '32', '21', '20.00', '66.67', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('372', '32', '22', '30.00', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('373', '32', '23', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('374', '32', '24', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('375', '32', '25', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('376', '32', '26', 'لم يرفع', '0.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('377', '32', '27', 'لم يرفع', '0.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('378', '32', '28', 'لم يلتزم', '0.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('384', '35', '20', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('385', '35', '21', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('386', '35', '22', 'قرأ', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('387', '35', '23', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('388', '35', '24', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('389', '35', '25', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('390', '35', '26', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('391', '35', '27', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('392', '35', '28', 'إلتزم', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('393', '36', '20', '100', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('394', '36', '21', '100', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('395', '36', '22', '100', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('396', '36', '23', '100', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('397', '36', '24', '100', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('398', '36', '25', '100', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('399', '36', '26', '0', '0.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('400', '36', '27', '100', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('401', '36', '28', '100', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('402', '37', '20', '0', '0.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('403', '37', '21', '100', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('404', '37', '22', '100', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('405', '37', '23', '0', '0.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('406', '37', '24', '100', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('407', '37', '25', '100', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('408', '37', '26', '100', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('409', '37', '27', '100', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('410', '37', '28', '100', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('411', '15', '1', '10', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('412', '15', '2', '96', '96.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('413', '15', '3', '95', '95.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('414', '15', '4', '95', '95.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('415', '15', '5', '95', '95.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('416', '15', '6', '71', '71.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('417', '15', '7', '10', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('418', '15', '8', '70', '70.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('419', '15', '9', '100', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('420', '15', '10', '10', '100.00', '');
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('421', '38', '20', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('422', '38', '21', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('423', '38', '22', 'قرأ', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('424', '38', '23', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('425', '38', '24', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('426', '38', '25', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('427', '38', '26', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('428', '38', '27', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('429', '38', '28', 'إلتزم', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('430', '39', '20', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('431', '39', '21', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('432', '39', '22', 'قرأ', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('433', '39', '23', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('434', '39', '24', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('435', '39', '25', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('436', '39', '26', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('437', '39', '27', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('438', '39', '28', 'إلتزم', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('439', '40', '20', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('440', '40', '21', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('441', '40', '22', 'قرأ', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('442', '40', '23', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('443', '40', '24', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('444', '40', '25', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('445', '40', '26', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('446', '40', '27', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('447', '40', '28', 'إلتزم', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('448', '41', '20', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('449', '41', '21', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('450', '41', '22', 'قرأ', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('451', '41', '23', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('452', '41', '24', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('453', '41', '25', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('454', '41', '26', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('455', '41', '27', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('456', '41', '28', 'إلتزم', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('457', '42', '20', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('458', '42', '21', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('459', '42', '22', 'قرأ', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('460', '42', '23', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('461', '42', '24', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('462', '42', '25', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('463', '42', '26', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('464', '42', '27', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('465', '42', '28', 'إلتزم', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('466', '43', '20', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('467', '43', '21', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('468', '43', '22', 'قرأ', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('469', '43', '23', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('470', '43', '24', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('471', '43', '25', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('472', '43', '26', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('473', '43', '27', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('474', '43', '28', 'إلتزم', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('475', '44', '20', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('476', '44', '21', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('477', '44', '22', 'قرأ', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('478', '44', '23', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('479', '44', '24', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('480', '44', '25', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('481', '44', '26', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('482', '44', '27', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('483', '44', '28', 'إلتزم', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('484', '45', '20', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('485', '45', '21', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('486', '45', '22', 'قرأ', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('487', '45', '23', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('488', '45', '24', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('489', '45', '25', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('490', '45', '26', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('491', '45', '27', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('492', '45', '28', 'إلتزم', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('493', '46', '20', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('494', '46', '21', 'طبق', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('495', '46', '22', 'قرأ', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('496', '46', '23', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('497', '46', '24', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('498', '46', '25', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('499', '46', '26', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('500', '46', '27', 'رفع', '100.00', NULL);
INSERT INTO `evaluation_answers` (`id`, `evaluation_id`, `section_id`, `raw_value`, `normalized_score`, `notes`) VALUES ('501', '46', '28', 'إلتزم', '100.00', NULL);


-- --------------------------------------------------------
-- Table structure for table `evaluation_import_batches`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `evaluation_import_batches`;
CREATE TABLE `evaluation_import_batches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uploaded_by_user_id` int(11) NOT NULL,
  `original_filename` varchar(255) NOT NULL,
  `status` enum('previewed','committing','completed','failed') NOT NULL DEFAULT 'previewed',
  `total_rows` int(10) unsigned NOT NULL DEFAULT 0,
  `valid_rows` int(10) unsigned NOT NULL DEFAULT 0,
  `invalid_rows` int(10) unsigned NOT NULL DEFAULT 0,
  `summary_json` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `committed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_import_batch_user_status` (`uploaded_by_user_id`,`status`),
  CONSTRAINT `fk_import_batch_user` FOREIGN KEY (`uploaded_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Data for table `evaluation_import_batches`
--

INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('1', '1', 'tesF438.tmp.xlsx', 'completed', '2', '2', '0', '{\"total\":2,\"valid\":2,\"invalid\":0,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 03:52:54', '2026-08-31 03:53:05');
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('2', '1', 'tesFD22.tmp.xlsx', 'previewed', '2', '1', '1', '{\"total\":2,\"valid\":1,\"invalid\":1,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 03:52:56', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('3', '1', 'tes65A.tmp.xlsx', 'previewed', '1', '0', '1', '{\"total\":1,\"valid\":0,\"invalid\":1,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 03:52:58', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('4', '1', 'tesF83.tmp.xlsx', 'previewed', '1', '0', '1', '{\"total\":1,\"valid\":0,\"invalid\":1,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 03:53:01', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('5', '1', 'tes185E.tmp.xlsx', 'previewed', '1', '0', '1', '{\"total\":1,\"valid\":0,\"invalid\":1,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 03:53:03', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('6', '1', 'tes2129.tmp.xlsx', 'previewed', '1', '0', '1', '{\"total\":1,\"valid\":0,\"invalid\":1,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 03:53:05', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('7', '1', 't_6ADF.tmp.xlsx', 'previewed', '1', '0', '1', '{\"total\":1,\"valid\":0,\"invalid\":1,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 03:53:24', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('8', '1', 't_73AA.tmp.xlsx', 'previewed', '1', '1', '0', '{\"total\":1,\"valid\":1,\"invalid\":0,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 03:53:26', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('9', '1', 't_7C84.tmp.xlsx', 'previewed', '1', '0', '1', '{\"total\":1,\"valid\":0,\"invalid\":1,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 03:53:29', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('10', '1', 't_8511.tmp.xlsx', 'previewed', '2', '1', '1', '{\"total\":2,\"valid\":1,\"invalid\":1,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 03:53:31', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('11', '1', 'test.xlsx', 'previewed', '2', '2', '0', '{\"total\":2,\"valid\":2,\"invalid\":0,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 04:03:36', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('12', '1', 'evaluation-template-1 (2).xlsx', 'previewed', '3', '0', '3', '{\"total\":3,\"valid\":0,\"invalid\":3,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 04:08:29', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('13', '1', 'tes5AEE.tmp.xlsx', 'previewed', '2', '2', '0', '{\"total\":2,\"valid\":2,\"invalid\":0,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 04:11:55', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('14', '1', 'evaluation-template-1 (2).xlsx', 'previewed', '3', '2', '1', '{\"total\":3,\"valid\":2,\"invalid\":1,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 04:12:34', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('15', '1', 'evaluation-template-1 (2).xlsx', 'completed', '2', '2', '0', '{\"total\":2,\"valid\":2,\"invalid\":0,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 04:13:51', '2026-08-31 04:13:58');
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('16', '1', 't136C.tmp.xlsx', 'previewed', '1', '0', '1', '{\"total\":1,\"valid\":0,\"invalid\":1,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 04:27:59', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('17', '1', 't8F34.tmp.xlsx', 'completed', '2', '2', '0', '{\"total\":2,\"valid\":2,\"invalid\":0,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 04:28:31', '2026-08-31 04:28:31');
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('18', '1', 't8F34.tmp.xlsx', 'previewed', '2', '2', '0', '{\"total\":2,\"valid\":2,\"invalid\":0,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 04:28:31', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('19', '1', 'evaluation-template-1 (3).xlsx', 'completed', '1', '1', '0', '{\"total\":1,\"valid\":1,\"invalid\":0,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 04:33:48', '2026-08-31 04:33:51');
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('20', '1', 'evaluation-template-1 (4).xlsx', 'completed', '1', '1', '0', '{\"total\":1,\"valid\":1,\"invalid\":0,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-08-31 19:17:20', '2026-08-31 19:17:23');
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('21', '1', 'evaluation-template-1 (5).xlsx', 'completed', '1', '1', '0', '{\"total\":1,\"valid\":1,\"invalid\":0,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-09-01 01:47:34', '2026-09-01 01:47:54');
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('22', '1', 'preview_test.xlsx', 'previewed', '4', '0', '4', '{\"total\":4,\"valid\":0,\"invalid\":4,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 03:32:00', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('23', '1', 'preview_correct.xlsx', 'previewed', '4', '2', '2', '{\"total\":4,\"valid\":2,\"invalid\":2,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 03:32:59', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('24', '1', 'commit_test.xlsx', 'previewed', '2', '1', '1', '{\"total\":2,\"valid\":1,\"invalid\":1,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 03:33:16', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('25', '1', 'commit_debug.xlsx', 'previewed', '2', '1', '1', '{\"total\":2,\"valid\":1,\"invalid\":1,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 03:33:37', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('26', '1', 'final_commit.xlsx', 'previewed', '2', '2', '0', '{\"total\":2,\"valid\":2,\"invalid\":0,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 03:34:21', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('28', '1', 'date_flex.xlsx', 'previewed', '1', '1', '0', '{\"total\":1,\"valid\":1,\"invalid\":0,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 03:44:15', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('29', '1', 'evaluation-template-2 (5).xlsx', 'completed', '1', '1', '0', '{\"total\":1,\"valid\":1,\"invalid\":0,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 03:46:26', '2026-09-01 03:46:29');
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('30', '1', 'date_flex.xlsx', 'previewed', '100', '1', '99', '{\"total\":100,\"valid\":1,\"invalid\":99,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 04:04:32', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('31', '1', 'valid.xlsx', 'previewed', '100', '1', '99', '{\"total\":100,\"valid\":1,\"invalid\":99,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 04:08:39', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('32', '1', 'dup_code.xlsx', 'previewed', '100', '1', '99', '{\"total\":100,\"valid\":1,\"invalid\":99,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 04:08:40', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('33', '1', 'empty_both.xlsx', 'previewed', '100', '0', '100', '{\"total\":100,\"valid\":0,\"invalid\":100,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 04:08:41', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('34', '1', 'future_date.xlsx', 'previewed', '100', '0', '100', '{\"total\":100,\"valid\":0,\"invalid\":100,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 04:08:41', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('35', '1', 'formula.xlsx', 'previewed', '100', '0', '100', '{\"total\":100,\"valid\":0,\"invalid\":100,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 04:08:42', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('36', '1', 'branch_mismatch.xlsx', 'previewed', '100', '1', '99', '{\"total\":100,\"valid\":1,\"invalid\":99,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 04:08:42', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('37', '1', 'final_exists.xlsx', 'previewed', '100', '1', '99', '{\"total\":100,\"valid\":1,\"invalid\":99,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 04:08:43', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('38', '1', 'over.xlsx', 'previewed', '101', '101', '0', '{\"total\":101,\"valid\":101,\"invalid\":0,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 04:08:44', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('39', '1', 'date_flex.xlsx', 'previewed', '100', '1', '99', '{\"total\":100,\"valid\":1,\"invalid\":99,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 04:08:44', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('40', '1', 'quick.xlsx', 'previewed', '1', '0', '1', '{\"total\":1,\"valid\":0,\"invalid\":1,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 04:09:20', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('41', '1', 'quick.xlsx', 'previewed', '1', '0', '1', '{\"total\":1,\"valid\":0,\"invalid\":1,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 04:09:51', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('42', '1', 'mismatch2.xlsx', 'previewed', '1', '0', '1', '{\"total\":1,\"valid\":0,\"invalid\":1,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 04:10:15', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('45', '1', 'evaluation-template-2 (5).xlsx', 'previewed', '1', '0', '1', '{\"total\":1,\"valid\":0,\"invalid\":1,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 04:36:22', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('48', '1', 'evaluation-template-1 (2).xlsx', 'previewed', '1', '0', '1', '{\"total\":1,\"valid\":0,\"invalid\":1,\"template_id\":1,\"template_name\":\"نموذج تقييم الأداء السنوي\"}', '2026-09-01 04:39:41', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('49', '1', 'evaluation-template-2 (5).xlsx', 'previewed', '1', '0', '1', '{\"total\":1,\"valid\":0,\"invalid\":1,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 04:41:15', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('50', '1', 'evaluation-template-2 (10).xlsx', 'completed', '1', '1', '0', '{\"total\":1,\"valid\":1,\"invalid\":0,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 04:42:40', '2026-09-01 04:42:43');
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('51', '1', 'free_eval.xlsx', 'previewed', '2', '0', '2', '{\"total\":2,\"valid\":0,\"invalid\":2,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 05:34:56', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('52', '1', 'free_eval.xlsx', 'previewed', '2', '1', '1', '{\"total\":2,\"valid\":1,\"invalid\":1,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 05:35:45', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('54', '1', 'evaluation-template-2 (11).xlsx', 'completed', '1', '1', '0', '{\"total\":1,\"valid\":1,\"invalid\":0,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 05:42:55', '2026-09-01 05:42:57');
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('55', '1', 'evaluation-template-2 (12).xlsx', 'previewed', '3', '0', '3', '{\"total\":3,\"valid\":0,\"invalid\":3,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-01 14:33:02', NULL);
INSERT INTO `evaluation_import_batches` (`id`, `uploaded_by_user_id`, `original_filename`, `status`, `total_rows`, `valid_rows`, `invalid_rows`, `summary_json`, `created_at`, `committed_at`) VALUES ('56', '1', 'evaluation-template-2 (13).xlsx', 'completed', '9', '9', '0', '{\"total\":9,\"valid\":9,\"invalid\":0,\"template_id\":2,\"template_name\":\"التقرير الشهري لاستمارة تقييم الأداء العملي الشهري\"}', '2026-09-02 05:41:37', '2026-09-02 05:41:41');


-- --------------------------------------------------------
-- Backup completed: 2026-09-02 05:51:32
-- Total tables: 15
-- Total rows: 568
-- Memory peak usage: 6 MB
-- --------------------------------------------------------
